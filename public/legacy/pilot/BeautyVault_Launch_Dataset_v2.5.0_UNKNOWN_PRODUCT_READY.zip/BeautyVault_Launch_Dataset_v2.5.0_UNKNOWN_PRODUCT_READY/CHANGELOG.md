# 2.5.0 — 2026-09-04

- Added a strict unknown-product submission contract and a fail-closed identity capture policy.
- Added barcode digits, URL, name-and-brand and one-photo intake routes without treating them as verified identity.
- Added a clearly synthetic Sara walkthrough profile, excluded from production, pilot metrics and training.
- Preserved the real readiness counts: physical passports, verified formulas, verified SKUs, real sessions and outcomes remain zero.

# 2.1.0

- Added strict schemas for Iranian market demand, search queries, reviews and aspect annotations.
- Added a 30-item candidate worklist outside production; no candidate is recommendation-eligible.
- Added individual preference dimensions without stereotyping Iranian users.
- Added SOP separating product-formula feedback from seller and logistics feedback.
- Added the Tehran pre-purchase and post-use private-beta contract.
- Extended validation and referential-integrity checks for the new tables.

# 2.0.0

- Replaced descriptive pseudo-schemas with executable JSON Schema Draft 2020-12.
- Split free-form events into eight typed event contracts.
- Normalized product, formula, market SKU, seller, offer, price, availability and authenticity.
- Added GTIN/IRC/TTAC fields for Iran.
- Added full INCI order, concentration provenance, vehicle, pH, fragrance, allergens, UV filters and formula hashes.
- Added multidimensional baseline-linked outcomes.
- Added N-of-1, rejected purchase history, abstain logging and expert review.
- Added evidence and rule versioning.
- Added privacy consent ledger and optional Research Vault.
- Quarantined incomplete v1 seeds and synthetic samples.
- Added PostgreSQL constraints, Ajv validation and fail-closed launch gates.

## 2.2.0 — 2026-09-03
- Replaced generic launch emphasis with a purchase-decision Gate A of five Iranian-market products.
- Added five metadata-verified products, ten dated public demand observations, five privacy-minimized review observations, five candidate evidence records and five draft safety/abstention rules.
- Added Gate A passports and an explicit remote-to-physical verification SOP.
- Kept all products recommendation-ineligible until physical label, full ordered INCI, formula linkage and clinical rule review are complete.
# 2.4.0 — 2026-09-03

- Reconciled manifest counts with physical JSONL row counts.
- Rebuilt the 15-product launch catalog as 15 machine-readable records.
- Added five candidate Iranian market SKUs without pretending their formulas are resolved.
- Added five dated price and availability observations with seller and offer linkage.
- Added a data-quality report separating resolved gaps from physical-evidence blockers.
- Changed the phase-one validation gate to 15 sessions / 10 usable / 30% decision change or rational stop / 40% day-14 return / two payments.
- Preserved fail-closed recommendation policy; verified formula, clinical rules, real outcomes and recommendation-eligible products remain zero.

# 2.3.0 — 2026-09-03

- Added evidence-grade physical passport intake for the five Gate A SKUs.
- Added closed concierge decision contract and validation-session schema.
- Explicitly preserved zero completed physical passports until real package evidence is supplied.
- Added week 1–2 execution and behavioral validation protocol.
