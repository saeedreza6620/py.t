# Validation

`validate.mjs` performs:

- Draft 2020-12 JSON Schema validation with Ajv
- JSONL parse checks
- uniqueness checks
- foreign-key coverage
- product recommendation eligibility checks
- launch-blocker generation

Run:

```bash
npm install
npm run validate
```
