import fs from "node:fs";
import path from "node:path";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const failures = [];
const load = (name) => {
  const p = path.join(root,"production",name);
  const text = fs.readFileSync(p,"utf8").trim();
  if (!text) return [];
  return text.split(/\r?\n/).map((line,i)=>{
    try { return JSON.parse(line); }
    catch(e) { failures.push(`${name}:${i+1}: invalid JSON: ${e.message}`); return null; }
  }).filter(Boolean);
};
const tables = Object.fromEntries(fs.readdirSync(path.join(root,"production")).filter(x=>x.endsWith(".jsonl")).map(x=>[x,load(x)]));
const ids = {
  "sources.jsonl":"source_id","brands.jsonl":"brand_id","products.jsonl":"product_id",
  "market_skus.jsonl":"market_sku_id","sellers.jsonl":"seller_id","product_offers.jsonl":"offer_id",
  "price_observations.jsonl":"price_observation_id","availability_observations.jsonl":"availability_observation_id",
  "market_demand_observations.jsonl":"demand_observation_id","product_review_observations.jsonl":"review_observation_id",
  "evidence_records.jsonl":"evidence_id","decision_rules.jsonl":"rule_id"
};
for (const [table,key] of Object.entries(ids)) {
  const seen=new Set();
  for (const row of tables[table]||[]) {
    if (!row[key]) failures.push(`${table}: missing ${key}`);
    if (seen.has(row[key])) failures.push(`${table}: duplicate ${key}=${row[key]}`);
    seen.add(row[key]);
  }
}
const sourceIds=new Set((tables["sources.jsonl"]||[]).map(x=>x.source_id));
const brandIds=new Set((tables["brands.jsonl"]||[]).map(x=>x.brand_id));
const productIds=new Set((tables["products.jsonl"]||[]).map(x=>x.product_id));
const marketSkuIds=new Set((tables["market_skus.jsonl"]||[]).map(x=>x.market_sku_id));
const sellerIds=new Set((tables["sellers.jsonl"]||[]).map(x=>x.seller_id));
const offerIds=new Set((tables["product_offers.jsonl"]||[]).map(x=>x.offer_id));
for (const b of tables["brands.jsonl"]||[]) for (const s of b.provenance?.source_ids||[]) if(!sourceIds.has(s)) failures.push(`brand ${b.brand_id}: orphan source ${s}`);
for (const p of tables["products.jsonl"]||[]) {
  if(!brandIds.has(p.brand_id)) failures.push(`product ${p.product_id}: orphan brand ${p.brand_id}`);
  for (const s of p.provenance?.source_ids||[]) if(!sourceIds.has(s)) failures.push(`product ${p.product_id}: orphan source ${s}`);
  if(p.recommendation_eligible && p.eligibility_blockers?.length) failures.push(`product ${p.product_id}: eligible with blockers`);
}
for (const s of tables["market_skus.jsonl"]||[]) {
  if(!productIds.has(s.product_id)) failures.push(`market SKU ${s.market_sku_id}: orphan product ${s.product_id}`);
  if(s.status==="verified" && !s.formula_version_id) failures.push(`market SKU ${s.market_sku_id}: verified without formula`);
}
for (const o of tables["product_offers.jsonl"]||[]) {
  if(!marketSkuIds.has(o.market_sku_id)) failures.push(`offer ${o.offer_id}: orphan market SKU`);
  if(!sellerIds.has(o.seller_id)) failures.push(`offer ${o.offer_id}: orphan seller`);
}
for (const p of tables["price_observations.jsonl"]||[]) {
  if(!offerIds.has(p.offer_id)) failures.push(`price ${p.price_observation_id}: orphan offer`);
  if(!sourceIds.has(p.source_id)) failures.push(`price ${p.price_observation_id}: orphan source`);
}
for (const a of tables["availability_observations.jsonl"]||[]) {
  if(!offerIds.has(a.offer_id)) failures.push(`availability ${a.availability_observation_id}: orphan offer`);
  if(!sourceIds.has(a.source_id)) failures.push(`availability ${a.availability_observation_id}: orphan source`);
}
for (const d of tables["market_demand_observations.jsonl"]||[]) {
  if(d.product_id && !productIds.has(d.product_id)) failures.push(`demand ${d.demand_observation_id}: orphan product`);
  if(!sourceIds.has(d.source_id)) failures.push(`demand ${d.demand_observation_id}: orphan source`);
  if(!["review_count","rating_count"].includes(d.signal_type)) failures.push(`demand ${d.demand_observation_id}: unsupported signal`);
}
for (const r of tables["product_review_observations.jsonl"]||[]) {
  if(!productIds.has(r.product_id)) failures.push(`review ${r.review_observation_id}: orphan product`);
  if(!sourceIds.has(r.source_id)) failures.push(`review ${r.review_observation_id}: orphan source`);
  if(r.personal_identifiers_removed!==true) failures.push(`review ${r.review_observation_id}: privacy flag not true`);
}
for (const e of tables["evidence_records.jsonl"]||[]) if(e.status!=="candidate") failures.push(`evidence ${e.evidence_id}: must remain candidate before expert review`);
for (const r of tables["decision_rules.jsonl"]||[]) if(r.status!=="draft") failures.push(`rule ${r.rule_id}: must remain draft before clinical review`);

const passports=JSON.parse(fs.readFileSync(path.join(root,"reference/gate_a_product_passports_remote_verified.json"),"utf8"));
if(passports.passports?.length!==5) failures.push("Gate A passport count must equal 5");
if(passports.passports?.some(p=>p.recommendation_eligible)) failures.push("No Gate A passport may be recommendation eligible before physical verification");
const catalog=JSON.parse(fs.readFileSync(path.join(root,"reference/launch_catalog_15_purchase_driven.json"),"utf8"));
if(catalog.items?.length!==15) failures.push("Launch catalog must contain exactly 15 machine-readable rows");
if(catalog.items?.some(p=>p.recommendation_eligible)) failures.push("No launch catalog item may be recommendation eligible before verification");

const report={schema_version:"2.5.0",validated_at:new Date().toISOString(),core_syntax_and_integrity_status:failures.length?"FAIL":"PASS",ready_for_closed_concierge_validation:failures.length===0,unknown_product_intake_status:"READY",public_recommendation_status:"BLOCKED",counts:{sources:(tables["sources.jsonl"]||[]).length,brands:(tables["brands.jsonl"]||[]).length,products:(tables["products.jsonl"]||[]).length,candidate_market_skus:(tables["market_skus.jsonl"]||[]).filter(x=>x.status==="candidate").length,verified_market_skus:(tables["market_skus.jsonl"]||[]).filter(x=>x.status==="verified").length,price_observations:(tables["price_observations.jsonl"]||[]).length,availability_observations:(tables["availability_observations.jsonl"]||[]).length,demand_observations:(tables["market_demand_observations.jsonl"]||[]).length,review_observations:(tables["product_review_observations.jsonl"]||[]).length,candidate_evidence:(tables["evidence_records.jsonl"]||[]).length,draft_rules:(tables["decision_rules.jsonl"]||[]).length,launch_catalog_items:catalog.items?.length||0,gate_a_passports:passports.passports?.length||0,physical_passports_complete:0,unknown_product_submissions:0,synthetic_demo_profiles:1,real_validation_sessions:0,concierge_mvp_products:5},failures,remaining_public_launch_blockers:["physical label photos","verified GTIN/IRC","full ordered INCI","formula-version linkage","clinical rule review","real behavior and payment validation"],note:"PASS means internal consistency, low-friction unknown-product capture and closed-pilot fitness only. It never means the product formulas or recommendations are verified."};
fs.writeFileSync(path.join(root,"launch/core_validation_report.json"),JSON.stringify(report,null,2)+"\n");
console.log(JSON.stringify(report,null,2));
if(failures.length) process.exit(1);
