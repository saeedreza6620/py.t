import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import Ajv2020 from "ajv/dist/2020.js";
import addFormats from "ajv-formats";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const ajv = new Ajv2020({allErrors: true, strict: true, strictRequired: false});
addFormats(ajv);

function walk(dir) {
  return fs.readdirSync(dir, {withFileTypes: true}).flatMap((entry) => {
    const p = path.join(dir, entry.name);
    return entry.isDirectory() ? walk(p) : [p];
  });
}

for (const file of walk(path.join(root, "schemas")).filter((p) => p.endsWith(".json"))) {
  ajv.addSchema(JSON.parse(fs.readFileSync(file, "utf8")));
}

const mapping = {
  "sources.jsonl": "https://schemas.beautyvault.local/v2/source_record.schema.json",
  "brands.jsonl": "https://schemas.beautyvault.local/v2/brand.schema.json",
  "products.jsonl": "https://schemas.beautyvault.local/v2/product.schema.json",
  "formula_versions.jsonl": "https://schemas.beautyvault.local/v2/formula_version.schema.json",
  "market_skus.jsonl": "https://schemas.beautyvault.local/v2/market_sku.schema.json",
  "sellers.jsonl": "https://schemas.beautyvault.local/v2/seller.schema.json",
  "product_offers.jsonl": "https://schemas.beautyvault.local/v2/product_offer.schema.json",
  "price_observations.jsonl": "https://schemas.beautyvault.local/v2/price_observation.schema.json",
  "availability_observations.jsonl": "https://schemas.beautyvault.local/v2/availability_observation.schema.json",
  "authenticity_observations.jsonl": "https://schemas.beautyvault.local/v2/authenticity_observation.schema.json",
  "user_profiles.jsonl": "https://schemas.beautyvault.local/v2/user_profile.schema.json",
  "user_states.jsonl": "https://schemas.beautyvault.local/v2/user_state.schema.json",
  "consent_records.jsonl": "https://schemas.beautyvault.local/v2/consent_record.schema.json",
  "routine_snapshots.jsonl": "https://schemas.beautyvault.local/v2/routine_snapshot.schema.json",
  "exposures.jsonl": "https://schemas.beautyvault.local/v2/exposure.schema.json",
  "outcomes.jsonl": "https://schemas.beautyvault.local/v2/outcome.schema.json",
  "n_of_1_protocols.jsonl": "https://schemas.beautyvault.local/v2/n_of_1_protocol.schema.json",
  "evidence_records.jsonl": "https://schemas.beautyvault.local/v2/evidence_record.schema.json",
  "decision_rules.jsonl": "https://schemas.beautyvault.local/v2/decision_rule.schema.json",
  "recommendation_logs.jsonl": "https://schemas.beautyvault.local/v2/recommendation_log.schema.json",
  "expert_review_cases.jsonl": "https://schemas.beautyvault.local/v2/expert_review_case.schema.json",
  "image_observations.jsonl": "https://schemas.beautyvault.local/v2/image_observation.schema.json",
  "market_demand_observations.jsonl": "https://schemas.beautyvault.local/v2/market_demand_observation.schema.json",
  "search_query_observations.jsonl": "https://schemas.beautyvault.local/v2/search_query_observation.schema.json",
  "product_review_observations.jsonl": "https://schemas.beautyvault.local/v2/product_review_observation.schema.json",
  "review_aspect_annotations.jsonl": "https://schemas.beautyvault.local/v2/review_aspect_annotation.schema.json",
  "events.jsonl": "https://schemas.beautyvault.local/v2/events/event.schema.json"
};

function loadJsonl(name) {
  const p = path.join(root, "production", name);
  const text = fs.readFileSync(p, "utf8").trim();
  if (!text) return [];
  return text.split(/\r?\n/).map((line, i) => {
    try { return JSON.parse(line); }
    catch (e) { throw new Error(`${name}:${i + 1}: invalid JSON: ${e.message}`); }
  });
}

const errors = [];
const tables = {};
for (const [name, schemaId] of Object.entries(mapping)) {
  const validate = ajv.getSchema(schemaId);
  if (!validate) throw new Error(`Schema not registered: ${schemaId}`);
  const rows = loadJsonl(name);
  tables[name] = rows;
  rows.forEach((row, i) => {
    if (!validate(row)) errors.push({table: name, row: i + 1, errors: validate.errors});
  });
}

function unique(table, key) {
  const seen = new Set();
  for (const row of tables[table]) {
    if (seen.has(row[key])) errors.push({table, key, value: row[key], error: "duplicate"});
    seen.add(row[key]);
  }
  return seen;
}

const sourceIds = unique("sources.jsonl", "source_id");
const brandIds = unique("brands.jsonl", "brand_id");
const productIds = unique("products.jsonl", "product_id");
const formulaIds = unique("formula_versions.jsonl", "formula_version_id");
const marketSkuIds = unique("market_skus.jsonl", "market_sku_id");
const sellerIds = unique("sellers.jsonl", "seller_id");
const offerIds = unique("product_offers.jsonl", "offer_id");
const userIds = unique("user_profiles.jsonl", "user_id");
const exposureIds = unique("exposures.jsonl", "exposure_id");
const reviewObservationIds = unique("product_review_observations.jsonl", "review_observation_id");

for (const row of tables["brands.jsonl"]) {
  for (const id of row.provenance.source_ids) if (!sourceIds.has(id)) errors.push({table:"brands.jsonl", id:row.brand_id, error:`orphan source ${id}`});
}
for (const row of tables["products.jsonl"]) {
  if (!brandIds.has(row.brand_id)) errors.push({table:"products.jsonl", id:row.product_id, error:`orphan brand ${row.brand_id}`});
  for (const id of row.provenance.source_ids) if (!sourceIds.has(id)) errors.push({table:"products.jsonl", id:row.product_id, error:`orphan source ${id}`});
  if (row.recommendation_eligible && row.eligibility_blockers.length) errors.push({table:"products.jsonl", id:row.product_id, error:"eligible product has blockers"});
}
for (const row of tables["formula_versions.jsonl"]) {
  if (!productIds.has(row.product_id)) errors.push({table:"formula_versions.jsonl", id:row.formula_version_id, error:`orphan product ${row.product_id}`});
  for (const id of row.provenance.source_ids) if (!sourceIds.has(id)) errors.push({table:"formula_versions.jsonl", id:row.formula_version_id, error:`orphan source ${id}`});
}
for (const row of tables["market_skus.jsonl"]) {
  if (!productIds.has(row.product_id)) errors.push({table:"market_skus.jsonl", id:row.market_sku_id, error:`orphan product ${row.product_id}`});
  if (row.formula_version_id !== null && !formulaIds.has(row.formula_version_id)) errors.push({table:"market_skus.jsonl", id:row.market_sku_id, error:`orphan formula ${row.formula_version_id}`});
  if (row.status === "verified" && row.formula_version_id === null) errors.push({table:"market_skus.jsonl", id:row.market_sku_id, error:"verified SKU without resolved formula"});
}
for (const row of tables["product_offers.jsonl"]) {
  if (!marketSkuIds.has(row.market_sku_id)) errors.push({table:"product_offers.jsonl", id:row.offer_id, error:`orphan market SKU ${row.market_sku_id}`});
  if (!sellerIds.has(row.seller_id)) errors.push({table:"product_offers.jsonl", id:row.offer_id, error:`orphan seller ${row.seller_id}`});
}
for (const row of tables["price_observations.jsonl"]) {
  if (!offerIds.has(row.offer_id)) errors.push({table:"price_observations.jsonl", id:row.price_observation_id, error:`orphan offer ${row.offer_id}`});
  if (!sourceIds.has(row.source_id)) errors.push({table:"price_observations.jsonl", id:row.price_observation_id, error:`orphan source ${row.source_id}`});
}
for (const row of tables["availability_observations.jsonl"]) {
  if (!offerIds.has(row.offer_id)) errors.push({table:"availability_observations.jsonl", id:row.availability_observation_id, error:`orphan offer ${row.offer_id}`});
  if (!sourceIds.has(row.source_id)) errors.push({table:"availability_observations.jsonl", id:row.availability_observation_id, error:`orphan source ${row.source_id}`});
}
for (const row of tables["exposures.jsonl"]) {
  if (!userIds.has(row.user_id)) errors.push({table:"exposures.jsonl", id:row.exposure_id, error:`orphan user ${row.user_id}`});
  if (!marketSkuIds.has(row.market_sku_id)) errors.push({table:"exposures.jsonl", id:row.exposure_id, error:`orphan market SKU ${row.market_sku_id}`});
  if (!formulaIds.has(row.formula_version_id)) errors.push({table:"exposures.jsonl", id:row.exposure_id, error:`orphan formula ${row.formula_version_id}`});
}
for (const row of tables["outcomes.jsonl"]) {
  if (!userIds.has(row.user_id)) errors.push({table:"outcomes.jsonl", id:row.outcome_id, error:`orphan user ${row.user_id}`});
  if (!exposureIds.has(row.exposure_id)) errors.push({table:"outcomes.jsonl", id:row.outcome_id, error:`orphan exposure ${row.exposure_id}`});
}
for (const row of tables["market_demand_observations.jsonl"]) {
  if (!sourceIds.has(row.source_id)) errors.push({table:"market_demand_observations.jsonl", id:row.demand_observation_id, error:`orphan source ${row.source_id}`});
  if (row.product_id !== null && !productIds.has(row.product_id)) errors.push({table:"market_demand_observations.jsonl", id:row.demand_observation_id, error:`orphan product ${row.product_id}`});
  if (row.market_sku_id !== null && !marketSkuIds.has(row.market_sku_id)) errors.push({table:"market_demand_observations.jsonl", id:row.demand_observation_id, error:`orphan market SKU ${row.market_sku_id}`});
}
for (const row of tables["search_query_observations.jsonl"]) {
  if (!sourceIds.has(row.source_id)) errors.push({table:"search_query_observations.jsonl", id:row.search_observation_id, error:`orphan source ${row.source_id}`});
}
for (const row of tables["product_review_observations.jsonl"]) {
  if (!sourceIds.has(row.source_id)) errors.push({table:"product_review_observations.jsonl", id:row.review_observation_id, error:`orphan source ${row.source_id}`});
  if (!productIds.has(row.product_id)) errors.push({table:"product_review_observations.jsonl", id:row.review_observation_id, error:`orphan product ${row.product_id}`});
  if (row.market_sku_id !== null && !marketSkuIds.has(row.market_sku_id)) errors.push({table:"product_review_observations.jsonl", id:row.review_observation_id, error:`orphan market SKU ${row.market_sku_id}`});
  if (row.seller_id !== null && !sellerIds.has(row.seller_id)) errors.push({table:"product_review_observations.jsonl", id:row.review_observation_id, error:`orphan seller ${row.seller_id}`});
  if (row.formula_version_id !== null && !formulaIds.has(row.formula_version_id)) errors.push({table:"product_review_observations.jsonl", id:row.review_observation_id, error:`orphan formula ${row.formula_version_id}`});
}
for (const row of tables["review_aspect_annotations.jsonl"]) {
  if (!reviewObservationIds.has(row.review_observation_id)) errors.push({table:"review_aspect_annotations.jsonl", id:row.annotation_id, error:`orphan review observation ${row.review_observation_id}`});
}

const eligible = tables["products.jsonl"].filter((r) => r.recommendation_eligible);
for (const product of eligible) {
  const formulas = tables["formula_versions.jsonl"].filter((f) => f.product_id === product.product_id && f.market === "IR" && f.formula_status === "verified");
  const skus = tables["market_skus.jsonl"].filter((s) => s.product_id === product.product_id && s.market === "IR" && s.status === "verified");
  if (!formulas.length || !skus.length) errors.push({table:"products.jsonl", id:product.product_id, error:"recommendation eligible without verified IR formula and SKU"});
}

const counts = Object.fromEntries(Object.entries(tables).map(([k, v]) => [k, v.length]));
const blockers = [];
if (!tables["formula_versions.jsonl"].some((r) => r.market === "IR" && r.formula_status === "verified")) blockers.push("No verified IR formula versions");
if (!tables["market_skus.jsonl"].some((r) => r.market === "IR" && r.status === "verified")) blockers.push("No verified IR market SKUs with GTIN/IRC");
if (!tables["decision_rules.jsonl"].some((r) => r.status === "active")) blockers.push("No clinically reviewed active decision rules");
if (counts["outcomes.jsonl"] === 0) blockers.push("No real longitudinal outcome records");
if (eligible.length === 0) blockers.push("No recommendation-eligible products");

const report = {
  schema_version: "2.5.0",
  validated_at: new Date().toISOString(),
  schema_and_integrity_status: errors.length ? "FAIL" : "PASS",
  public_launch_status: blockers.length || errors.length ? "BLOCKED" : "READY",
  counts,
  validation_errors: errors,
  launch_blockers: blockers,
  statement: "A PASS validation means the package is internally consistent. It does not override the launch blockers."
};
fs.writeFileSync(path.join(root, "launch", "generated_validation_report.json"), JSON.stringify(report, null, 2) + "\n");
console.log(JSON.stringify(report, null, 2));
if (errors.length) process.exit(1);
