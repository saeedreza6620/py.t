# Migration policy

- نسخهٔ schema با Semantic Versioning نگهداری می‌شود.
- تغییر breaking فقط با major version جدید مجاز است.
- migration باید idempotent، قابل ممیزی و دارای dry-run باشد.
- دادهٔ قدیمی overwrite نمی‌شود؛ mapping و lineage نگهداری می‌شود.
- رکوردهای نامعتبر به quarantine منتقل می‌شوند، نه اینکه silently drop شوند.
- تبدیل تاریخ شمسی/epoch قبلی باید source value و normalized UTC را هر دو در migration log نگه دارد.
