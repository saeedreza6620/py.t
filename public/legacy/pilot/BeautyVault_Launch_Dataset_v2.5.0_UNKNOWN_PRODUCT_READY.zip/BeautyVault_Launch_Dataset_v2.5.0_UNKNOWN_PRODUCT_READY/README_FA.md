# BeautyVault Launch Dataset v2.5.0 — ورود محصول ناشناخته، بدون ادعای ساختگی

این بسته جایگزین معماری قبلی است و برای پیاده‌سازی فنی طراحی شده است، اما وضعیت آن عمداً
`BLOCKED_FOR_PUBLIC_LAUNCH` است. دلیل: هیچ دادهٔ تأییدنشده، فرمول حدس‌زده‌شده، قیمت ساختگی،
نتیجهٔ کاربر مصنوعی یا قاعدهٔ پزشکی بدون ممیزی وارد production نشده است.

## این بسته چه دارد؟

- JSON Schema اجرایی Draft 2020-12 با `required`، `enum`، range، format، nullable policy و eventهای مستقل
- گراف نرمال‌شدهٔ `product → formula_version → market_sku → seller → offer → observation`
- پشتیبانی از GTIN، IRC و نتیجهٔ استعلام اصالت TTAC برای بازار ایران
- رویدادهای مستقل ProductViewed، DecisionMade، UseStarted، AdherenceLogged،
  ReactionReported، OutcomeMeasured، ProductStopped و ProductRepurchased
- outcome چندبعدی متصل به baseline، adherence، confounder و quality
- پروتکل N-of-1، تاریخچهٔ رد خرید، recommendation/abstain log و expert review queue
- evidence registry قابل ممیزی و rule versioning
- consent ledger، Research Vault اختیاری و جداسازی هویت از دادهٔ پوستی
- PostgreSQL DDL، validator و launch gates
- quarantine برای داده‌های نسخهٔ قبلی که هنوز شرایط production را ندارند
- لایهٔ مستقل ثبت تقاضای بازار، جست‌وجو و کامنت بدون تبدیل آن‌ها به evidence پزشکی
- کاتالوگ دقیقاً ۱۵‌محصولی با ۵ محصول هسته، ۵ مقایسه و ۵ توسعهٔ پرریسک؛ همگی بدون مجوز recommendation
- پنج Market SKU کاندید برای بازار ایران؛ کاندید بودن با «تأیید SKU» فرق دارد
- پنج Snapshot قیمت و موجودی با فروشنده، لینک و زمان مشاهده؛ قیمت ویژگی ثابت محصول نیست
- ابعاد تجربهٔ ایرانی شامل رد سفیدی، پیل‌شدن، سازگاری با آرایش، بافت، اصالت و دسترسی
- قرارداد ورود محصول ناشناخته با چهار مسیر کم‌اصطکاک: رقم بارکد، لینک، نام و برند، یا یک عکس اختیاری
- پروفایل فرضی «سارا» فقط برای نمایش UI؛ خارج از production، آمار پایلوت و آموزش مدل

## محصولی که در ۱۵ مورد نیست چه می‌شود؟

محصول رد نمی‌شود. با کمترین داده وارد صف `queued_identity_resolution` می‌شود. رقم صحیح بارکد فقط
کنترل checksum است و مالکیت کد، اصالت، INCI، نسخه فرمول یا batch را تأیید نمی‌کند. اگر اسکن خودکار
مرورگر در دسترس نباشد، واردکردن رقم‌های زیر بارکد مسیر اصلی است. یک عکس برای ساخت رکورد صف کافی است؛
اما پاسپورت فیزیکی فقط پس از تطبیق لیبل همان بسته، شناسه، INCI مرتب، منبع و حل تعارض کامل می‌شود.

## قانون طلایی

وجود یک محصول در catalog به‌معنای مجازبودن آن برای recommendation نیست.
موتور باید فقط محصولی را استفاده کند که formula نسخهٔ ایران، منبع، زمان تأیید و market SKU معتبر دارد.

## اجرای اعتبارسنجی

```bash
npm install
npm run validate
```

گزارش در `launch/generated_validation_report.json` ساخته می‌شود.

## وضعیت داده در ۱۲ شهریور ۱۴۰۵

- پنج پاسپورت متادیتای آنلاین برای Gate A
- پنج SKU کاندید متصل به محصول؛ SKU تأییدشده: صفر
- پنج قیمت و پنج وضعیت موجودی تاریخ‌دار
- کاتالوگ ماشین‌خوان ۱۵ ردیفی (۵ Gate A + ۵ Gate B + ۵ Gate C)
- پنج پرونده دریافت مدرک فیزیکی؛ کامل‌شده: ۰ از ۵
- فرمول کامل و نسخه‌بندی‌شده بازار ایران: ۰
- وب‌فلو پنج‌محصولی و قرارداد جلسه ولیدیشن: آماده
- جلسه واقعی و پرداخت واقعی: ۰
- داده مصنوعی در production: ۰

شروع تست بسته مجاز است، اما توصیه قطعی و لانچ عمومی تا ورود عکس واقعی بسته‌ها، GTIN/IRC، INCI مرتب، نسخه فرمول و بازبینی بالینی مسدود می‌ماند. راهنمای عملی در `docs/WEEK1_WEEK2_EXECUTION_FA.md` و ورودی فیزیکی در `collection/physical_passport_intake.json` است.

این کمبودها پنهان نشده‌اند؛ در `launch/data_quality_report_v2.5.0.json` و `launch/launch_gates.json` به‌عنوان blocker ثبت شده‌اند. چیزی که از وب قابل تکمیل نیست در `docs/PHYSICAL_EVIDENCE_HANDOFF_FA.md` دقیقاً تحویل اپراتور شده است.
