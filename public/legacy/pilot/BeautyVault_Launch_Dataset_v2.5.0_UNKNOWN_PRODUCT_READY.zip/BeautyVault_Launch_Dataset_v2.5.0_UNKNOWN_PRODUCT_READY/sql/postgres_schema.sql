CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE source_record (
  source_id text PRIMARY KEY CHECK (source_id ~ '^[a-z][a-z0-9_]{2,79}$'),
  body jsonb NOT NULL
);

CREATE TABLE brand (
  brand_id text PRIMARY KEY CHECK (brand_id ~ '^[a-z][a-z0-9_]{2,79}$'),
  body jsonb NOT NULL
);

CREATE TABLE product (
  product_id text PRIMARY KEY CHECK (product_id ~ '^[a-z][a-z0-9_]{2,79}$'),
  brand_id text NOT NULL REFERENCES brand(brand_id),
  catalog_status text NOT NULL CHECK (catalog_status IN ('candidate','metadata_verified','active','discontinued','conflicted')),
  recommendation_eligible boolean NOT NULL DEFAULT false,
  body jsonb NOT NULL
);

CREATE TABLE formula_version (
  formula_version_id text PRIMARY KEY CHECK (formula_version_id ~ '^[a-z][a-z0-9_]{2,79}$'),
  product_id text NOT NULL REFERENCES product(product_id),
  market char(2) NOT NULL,
  valid_from date NOT NULL,
  valid_to date,
  formula_status text NOT NULL CHECK (formula_status IN ('candidate','verified','conflicted','deprecated')),
  full_inci_complete boolean NOT NULL,
  inci_normalized_hash_sha256 char(64) NOT NULL UNIQUE,
  body jsonb NOT NULL,
  CHECK (valid_to IS NULL OR valid_to >= valid_from),
  CHECK (formula_status <> 'verified' OR full_inci_complete)
);

CREATE TABLE market_sku (
  market_sku_id text PRIMARY KEY CHECK (market_sku_id ~ '^[a-z][a-z0-9_]{2,79}$'),
  product_id text NOT NULL REFERENCES product(product_id),
  formula_version_id text NULL REFERENCES formula_version(formula_version_id),
  market char(2) NOT NULL,
  gtin14 char(14),
  irc char(16),
  status text NOT NULL CHECK (status IN ('candidate','verified','inactive','conflicted')),
  body jsonb NOT NULL,
  CHECK (gtin14 IS NULL OR gtin14 ~ '^\d{14}$'),
  CHECK (irc IS NULL OR irc ~ '^\d{16}$'),
  CHECK (NOT (market = 'IR' AND status = 'verified') OR gtin14 IS NOT NULL OR irc IS NOT NULL)
);

CREATE UNIQUE INDEX uq_market_sku_gtin ON market_sku(gtin14) WHERE gtin14 IS NOT NULL;
CREATE UNIQUE INDEX uq_market_sku_irc ON market_sku(irc) WHERE irc IS NOT NULL;

CREATE TABLE seller (
  seller_id text PRIMARY KEY CHECK (seller_id ~ '^[a-z][a-z0-9_]{2,79}$'),
  body jsonb NOT NULL
);

CREATE TABLE product_offer (
  offer_id uuid PRIMARY KEY,
  market_sku_id text NOT NULL REFERENCES market_sku(market_sku_id),
  seller_id text NOT NULL REFERENCES seller(seller_id),
  offer_url text NOT NULL,
  first_seen_at timestamptz NOT NULL,
  last_seen_at timestamptz NOT NULL,
  body jsonb NOT NULL,
  CHECK (last_seen_at >= first_seen_at)
);

CREATE TABLE price_observation (
  price_observation_id uuid PRIMARY KEY,
  offer_id uuid NOT NULL REFERENCES product_offer(offer_id),
  amount_irr bigint NOT NULL CHECK (amount_irr >= 0),
  discounted_amount_irr bigint CHECK (discounted_amount_irr >= 0),
  observed_at timestamptz NOT NULL,
  source_id text NOT NULL REFERENCES source_record(source_id),
  body jsonb NOT NULL
);

CREATE TABLE availability_observation (
  availability_observation_id uuid PRIMARY KEY,
  offer_id uuid NOT NULL REFERENCES product_offer(offer_id),
  availability text NOT NULL CHECK (availability IN ('in_stock','out_of_stock','preorder','discontinued','unknown')),
  observed_at timestamptz NOT NULL,
  source_id text NOT NULL REFERENCES source_record(source_id),
  body jsonb NOT NULL
);

CREATE TABLE user_profile (
  user_id text PRIMARY KEY CHECK (user_id ~ '^usr_[a-z0-9]{20,40}$'),
  body jsonb NOT NULL
);

CREATE TABLE consent_record (
  consent_id uuid PRIMARY KEY,
  user_id text NOT NULL REFERENCES user_profile(user_id),
  purpose text NOT NULL,
  status text NOT NULL CHECK (status IN ('granted','withdrawn','expired')),
  body jsonb NOT NULL
);

CREATE TABLE routine_snapshot (
  routine_snapshot_id uuid PRIMARY KEY,
  user_id text NOT NULL REFERENCES user_profile(user_id),
  captured_at timestamptz NOT NULL,
  body jsonb NOT NULL
);

CREATE TABLE n_of_1_protocol (
  n_of_1_protocol_id uuid PRIMARY KEY,
  user_id text NOT NULL REFERENCES user_profile(user_id),
  body jsonb NOT NULL
);

CREATE TABLE exposure (
  exposure_id uuid PRIMARY KEY,
  cycle_id uuid NOT NULL,
  user_id text NOT NULL REFERENCES user_profile(user_id),
  market_sku_id text NOT NULL REFERENCES market_sku(market_sku_id),
  formula_version_id text NOT NULL REFERENCES formula_version(formula_version_id),
  routine_snapshot_id uuid NOT NULL REFERENCES routine_snapshot(routine_snapshot_id),
  n_of_1_protocol_id uuid REFERENCES n_of_1_protocol(n_of_1_protocol_id),
  started_at timestamptz NOT NULL,
  ended_at timestamptz,
  body jsonb NOT NULL,
  CHECK (ended_at IS NULL OR ended_at >= started_at)
);

CREATE TABLE outcome (
  outcome_id uuid PRIMARY KEY,
  exposure_id uuid NOT NULL REFERENCES exposure(exposure_id),
  user_id text NOT NULL REFERENCES user_profile(user_id),
  measured_at timestamptz NOT NULL,
  body jsonb NOT NULL
);

CREATE TABLE event (
  event_id uuid PRIMARY KEY,
  user_id text NOT NULL REFERENCES user_profile(user_id),
  event_type text NOT NULL CHECK (event_type IN (
    'ProductViewed','DecisionMade','UseStarted','AdherenceLogged',
    'ReactionReported','OutcomeMeasured','ProductStopped','ProductRepurchased'
  )),
  occurred_at timestamptz NOT NULL,
  recorded_at timestamptz NOT NULL,
  event_version integer NOT NULL CHECK (event_version >= 1),
  body jsonb NOT NULL,
  UNIQUE(event_id, event_version)
);

-- Typed event payloads remain validated by their own JSON Schemas before insertion.
-- No free-form production event is accepted by the API.
-- BeautyVault v2.1 Iran demand and review evidence layer.
-- These tables store market/user signals and never constitute clinical evidence.

CREATE TABLE IF NOT EXISTS market_demand_observation (
  demand_observation_id uuid PRIMARY KEY,
  product_id text NULL REFERENCES product(product_id),
  market_sku_id text NULL REFERENCES market_sku(market_sku_id),
  category_code text NOT NULL,
  source_id text NOT NULL REFERENCES source_record(source_id),
  signal_type text NOT NULL CHECK (signal_type IN ('marketplace_rank','review_count','rating_count','search_interest','partner_sales','partner_views','wishlist_count')),
  signal_value numeric NOT NULL CHECK (signal_value >= 0),
  signal_unit text NOT NULL CHECK (signal_unit IN ('rank','count','index_0_100','units_sold','views','unknown')),
  ranking_context text NULL,
  sponsored_or_promoted text NOT NULL CHECK (sponsored_or_promoted IN ('yes','no','unknown')),
  geography text NOT NULL CHECK (geography IN ('IR','Tehran','unknown')),
  window_start timestamptz NULL,
  window_end timestamptz NULL,
  observed_at timestamptz NOT NULL,
  source_url text NULL,
  confidence numeric NOT NULL CHECK (confidence BETWEEN 0 AND 1),
  CHECK (window_end IS NULL OR window_start IS NULL OR window_end >= window_start)
);

CREATE TABLE IF NOT EXISTS search_query_observation (
  search_observation_id uuid PRIMARY KEY,
  query_raw text NOT NULL,
  query_normalized_fa text NOT NULL,
  query_variants jsonb NOT NULL DEFAULT '[]'::jsonb,
  intent text NOT NULL CHECK (intent IN ('category','product','brand','concern','ingredient','comparison','authenticity','price','how_to_use')),
  category_code text NULL,
  concern_codes jsonb NOT NULL DEFAULT '[]'::jsonb,
  source_id text NOT NULL REFERENCES source_record(source_id),
  metric_type text NOT NULL CHECK (metric_type IN ('absolute_volume','relative_index','impressions','clicks','internal_searches')),
  metric_value numeric NOT NULL CHECK (metric_value >= 0),
  geography text NOT NULL CHECK (geography IN ('IR','Tehran','unknown')),
  window_start date NOT NULL,
  window_end date NOT NULL,
  observed_at timestamptz NOT NULL,
  confidence numeric NOT NULL CHECK (confidence BETWEEN 0 AND 1),
  CHECK (window_end >= window_start)
);

CREATE TABLE IF NOT EXISTS product_review_observation (
  review_observation_id uuid PRIMARY KEY,
  source_review_key_hash_sha256 char(64) NOT NULL UNIQUE,
  source_id text NOT NULL REFERENCES source_record(source_id),
  product_id text NOT NULL REFERENCES product(product_id),
  market_sku_id text NULL REFERENCES market_sku(market_sku_id),
  seller_id text NULL REFERENCES seller(seller_id),
  rating_1_5 numeric NULL CHECK (rating_1_5 BETWEEN 1 AND 5),
  review_text_redacted text NULL,
  review_language text NOT NULL CHECK (review_language IN ('fa','en','mixed','unknown')),
  purchase_verification text NOT NULL CHECK (purchase_verification IN ('verified_purchase','not_verified','unknown')),
  helpful_vote_count integer NULL CHECK (helpful_vote_count >= 0),
  reviewed_at timestamptz NULL,
  observed_at timestamptz NOT NULL,
  formula_linkage text NOT NULL CHECK (formula_linkage IN ('exact','probable','unknown')),
  formula_version_id text NULL REFERENCES formula_version(formula_version_id),
  personal_identifiers_removed boolean NOT NULL CHECK (personal_identifiers_removed = true),
  analysis_eligible boolean NOT NULL,
  exclusion_reason_codes jsonb NOT NULL DEFAULT '[]'::jsonb
);

CREATE TABLE IF NOT EXISTS review_aspect_annotation (
  annotation_id uuid PRIMARY KEY,
  review_observation_id uuid NOT NULL REFERENCES product_review_observation(review_observation_id) ON DELETE CASCADE,
  aspect_code text NOT NULL,
  target text NOT NULL CHECK (target IN ('product_formula','packaging','seller','logistics','unclear')),
  sentiment text NOT NULL CHECK (sentiment IN ('negative','neutral','positive','mixed')),
  severity smallint NULL CHECK (severity BETWEEN 0 AND 3),
  evidence_span_redacted text NULL,
  annotation_method text NOT NULL CHECK (annotation_method IN ('human','model','human_reviewed_model')),
  annotator_version text NOT NULL,
  confidence numeric NOT NULL CHECK (confidence BETWEEN 0 AND 1),
  UNIQUE (review_observation_id, aspect_code, target, annotator_version)
);
