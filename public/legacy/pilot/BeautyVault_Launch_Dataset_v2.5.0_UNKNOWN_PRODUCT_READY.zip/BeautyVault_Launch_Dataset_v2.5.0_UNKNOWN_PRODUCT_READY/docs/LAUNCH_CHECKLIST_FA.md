# چک‌لیست لانچ

## فنی

- [ ] تمام schemaها در CI validate شوند.
- [ ] uniqueness و foreign key در DB فعال باشد.
- [ ] migration آزمایش‌شده و rollback غیرمخرب وجود داشته باشد.
- [ ] UTC در backend و timezone کاربر جدا ثبت شود.
- [ ] production، candidate و quarantine دسترسی و مسیر جدا داشته باشند.
- [ ] موتور recommendation به‌صورت fail-closed کار کند.

## دادهٔ محصول ایران

- [ ] لیست اولویت محصول از فروش واقعی/شریک و با تاریخ مشخص ساخته شود.
- [ ] برای هر محصول توصیه‌شونده formula_version بازار ایران تأیید شود.
- [ ] GTIN یا IRC و نتیجهٔ کنترل اصالت ثبت شود.
- [ ] منبع و observed_at/verified_at برای هر رکورد موجود باشد.
- [ ] قیمت و موجودی observation باشند، نه ویژگی دائمی product.

## علمی و ایمنی

- [ ] هر rule فعال evidence_id معتبر داشته باشد.
- [ ] reviewer و تاریخ بازبینی ثبت شود.
- [ ] severe reaction و red flag مسیر عملیاتی آزموده‌شده داشته باشد.
- [ ] متن محصول «تشخیص پزشکی» وعده ندهد.

## حریم خصوصی

- [ ] consent سرویس، عکس خام، تحقیق و مدل جدا باشد.
- [ ] عکس خام پیش‌فرض ذخیره نشود.
- [ ] حذف/اصلاح/خروجی کاربر end-to-end تست شود.
- [ ] retention، encryption، access logs و incident response بررسی حقوقی/امنیتی شود.

## دادهٔ طولی

- [ ] baseline و exposure قبل از outcome موجود باشند.
- [ ] پایبندی و confounder ثبت شود.
- [ ] non-response و stop reason حذف نشوند.
- [ ] مدل فقط پس از تصویب sample/calibration/bias gate آموزش ببیند.
