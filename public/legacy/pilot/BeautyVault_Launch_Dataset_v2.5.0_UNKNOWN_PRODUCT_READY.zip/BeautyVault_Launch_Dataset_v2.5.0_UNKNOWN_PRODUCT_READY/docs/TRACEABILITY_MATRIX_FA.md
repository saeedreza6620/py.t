# ماتریس پوشش همهٔ تغییرات

| نیاز | محل اجرا |
|---|---|
| required/type/enum/range/format/nullable | `schemas/` |
| uniqueness و foreign key | `sql/postgres_schema.sql` و `scripts/validate.mjs` |
| schema version و migration | `MANIFEST.json` و `migrations/README.md` |
| تاریخ ISO 8601 UTC و timezone | `common.schema.json` و schema رویدادها |
| event مستقل برای هر رفتار | `schemas/events/` |
| INCI کامل، ترتیب، غلظت، vehicle، pH، fragrance، allergen | `formula_version.schema.json` |
| فیلتر ضدآفتاب، SPF و PA | `formula_version.schema.json` |
| GTIN، IRC، TTAC، UID/lot امن | `market_sku.schema.json` و `authenticity_observation.schema.json` |
| محصول جدا از فروشنده | product/formula/market_sku/seller/offer schemas |
| قیمت و موجودی سری‌زمانی | price و availability observation |
| baseline و outcome چندبعدی | `outcome.schema.json` و `reference/outcome_dimensions.json` |
| حداقل تغییر معنادار برای خود کاربر | `user_minimum_meaningful_change` |
| evidence_id، DOI/PMID، نوع مطالعه، جمعیت، grade و reviewer | `evidence_record.schema.json` |
| rule active/deprecated و نسخه | `decision_rule.schema.json` |
| N-of-1 و single change | `n_of_1_protocol.schema.json` و `exposure.schema.json` |
| خرید ردشده و دلیل | `DecisionMade` |
| تغییر فرمول/هش بسته‌بندی | `formula_version.schema.json` |
| expert review queue | `expert_review_case.schema.json` |
| candidate/exclusion/missing/confidence/abstain | `recommendation_log.schema.json` |
| عکس اختیاری، Face Mesh فقط QC، Research Vault | `image_observation.schema.json` |
| consent جداگانه برای سرویس/عکس/تحقیق/مدل | `consent_record.schema.json` |
| تفکیک عمومی و محرمانه | `governance/TRADE_SECRET_REGISTER_FA.md` |
| جلوگیری از استفادهٔ داده ناقص | `policies/recommendation_eligibility.json` |
| دادهٔ قبلی ناقص | `quarantine/` |
| گیت لانچ | `launch/launch_gates.json` |
