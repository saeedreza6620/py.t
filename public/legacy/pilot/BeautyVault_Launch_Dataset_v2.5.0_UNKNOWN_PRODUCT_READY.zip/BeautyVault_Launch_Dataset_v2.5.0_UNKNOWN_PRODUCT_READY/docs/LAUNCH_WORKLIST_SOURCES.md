# Launch worklist source log

Accessed: 2026-08-01. These sources establish candidate/demand signals only and do not verify Iranian formula versions, GTIN/IRC, authenticity, safety, efficacy or recommendation eligibility.

- Digikala, C-Prime Fusion Water SPF50: https://www.digikala.com/product/dkp-8675816/
- Digikala, Vitalayer Niacinamide Serum: https://www.digikala.com/product/dkp-12230709/
- Digikala, Vitalayer Hyaluronic Serum: https://www.digikala.com/product/dkp-10149023/
- Digikala, Dermalift Hydralift AC: https://www.digikala.com/product/dkp-1518148/
- Digikala, Dermalift Melalift: https://www.digikala.com/product/dkp-1518217/
- Digikala, Bright Max Niacinamide: https://www.digikala.com/product/dkp-11874164/
- Digikala, Glama Niacinamide: https://www.digikala.com/product/dkp-20881046/
- Digikala, Walbenor Niacinamide and Zinc: https://www.digikala.com/product/dkp-19233555/
- Digikala, Margarite Niacinamide: https://www.digikala.com/product/dkp-17251154/
- Digikala, No Acne Niacinamide: https://www.digikala.com/product/dkp-18173806/
- Khanoumi, oily-skin sunscreen editorial shortlist: https://www.khanoumi.com/blog/best-oily-skin-sunscreen-for-open-pores/
- Khanoumi, Iranian sunscreen editorial shortlist: https://www.khanoumi.com/blog/7-cheap-sunscreens-for-skin-protection/
- Khanoumi, face cleanser category: https://www.khanoumi.com/categories/skincare/cleanser/face-wash-toner
- Khanoumi, Vitalayer Niacinamide product page: https://www.khanoumi.com/products/vitalayer-niacinamide-serum-30-ml-75002
- Khanoumi, Ginagen brand article: https://www.khanoumi.com/blog/popular-ginagen-products/
- Khanoumi, Liesel brand article: https://www.khanoumi.com/blog/liesel-brand-introduction/
- Khanoumi, Revival brand page: https://www.khanoumi.com/brands/revival

Before promotion into production, the operator must capture exact package photographs, full ordered INCI, GTIN or IRC, license/importer information, formula hash, verification date and reviewer identity.
