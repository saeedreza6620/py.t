# پروتکل N-of-1 و outcome

1. پیش از تغییر، baseline با همان روش سنجش ثبت می‌شود.
2. در بازهٔ ارزیابی فقط یک تغییر اصلی مجاز است.
3. روتین هم‌زمان، برنامهٔ مصرف و عوامل مداخله‌گر ثبت می‌شوند.
4. adherence از scheduled/completed application محاسبه می‌شود.
5. follow-up بر اساس intent/formula/risk انتخاب می‌شود و باید clinical review داشته باشد.
6. outcome یک برچسب improved/same/worse نیست؛ مجموعه‌ای از measureهای عددی با baseline و quality است.
7. دادهٔ مشاهده‌ای به‌صورت پیش‌فرض ادعای علی نمی‌سازد. causal_interpretation حداکثر `moderate` است.
8. واکنش شدید، تعارض عکس/خوداظهاری، چند تغییر هم‌زمان یا confidence پایین وارد expert queue می‌شود.
9. عدم پاسخ و توقف نیز داده‌اند؛ حذف آن‌ها survivorship bias می‌سازد.
10. synthetic data هرگز جزو completed decision cycles یا دادهٔ آموزش مدل شمرده نمی‌شود.
