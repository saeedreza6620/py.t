# ثبت اسرار تجاری BeautyVault

## عمومی

- ارزش پیشنهادی «قبل از خرید چک کن؛ بعد از مصرف نتیجه را بسنج»
- توضیح‌های کوتاه قابل فهم برای کاربر
- سیاست حریم خصوصی و حق حذف/خروجی
- وجود confidence و امکان abstain
- نتایج اعتبارسنجی کلی و ناشناس

## محرمانه

- schema دقیق production و تعریف label/outcome
- وزن‌ها، thresholdها و confidence calibration
- منطق follow-up selection و cohort matching
- pipeline تطبیق formula_version و entity resolution
- قواعد ranking جایگزین و rejection modeling
- نرخ‌های داخلی واکنش/خطا و partner-level data
- pipeline پاک‌سازی، QA و expert adjudication

## کنترل‌های لازم

- NDA و انتقال مالکیت فکری برای کارمند/پیمانکار
- repository و dataset خصوصی
- least privilege و access log
- عدم تحویل کل دیتاست به پیمانکار
- API محدود، rate limit و جلوگیری از bulk export
- تفکیک test data از production
- ثبت نسخه و audit trail

منبع عمومی راهبرد حفاظت: `src_wipo_trade_secrets`.
